package client

import (
	"context"
	"io"
	"sync"
)

// RecvBuffer is a bounded in-memory byte buffer that decouples the DATA-frame
// reader (producer) from the local HTTP consumer (reader).
//
// Back-pressure chain:
//
//	slow HTTP consumer → RecvBuffer full → producer blocks → no new ACKs
//	→ server's inflight ≥ window → server pauses DATA frames
//	→ accel-proxy TCP recv-window shrinks → origin slows
//
// Lifecycle across reconnects:
//
//	Normal push:  Write → Write → ... → Close(nil)  → Read drains → EOF
//	Network error: Write → Write → [conn dies] → Reopen() → Write → ...
//
// Reopen() clears the closed flag so that a reconnected session can continue
// writing into the same buffer. The consumer (HTTP reader) never sees the
// transient disconnect — it simply blocks on Read() until new data arrives.
// Only a clean RST(EOF) from the server calls Close(nil) which delivers the
// real EOF to the consumer.
type RecvBuffer struct {
	mu       sync.Mutex
	notFull  *sync.Cond
	notEmpty *sync.Cond

	buf  []byte
	head int
	tail int
	size int
	cap  int

	closed   bool
	closeErr error
}

// NewRecvBuffer creates a buffer with the given capacity in bytes.
func NewRecvBuffer(capacity int) *RecvBuffer {
	b := &RecvBuffer{buf: make([]byte, capacity), cap: capacity}
	b.notFull = sync.NewCond(&b.mu)
	b.notEmpty = sync.NewCond(&b.mu)
	return b
}

// Write appends data into the buffer. Blocks if the buffer is full until
// space is available or ctx is cancelled.
func (b *RecvBuffer) Write(ctx context.Context, data []byte) error {
	written := 0
	for written < len(data) {
		b.mu.Lock()

		// Block on cond.Wait instead of busy-spinning.
		// A watcher goroutine broadcasts when ctx is cancelled.
		if b.size == b.cap && !b.closed {
			quit := make(chan struct{})
			go func() {
				select {
				case <-ctx.Done():
					b.notFull.Broadcast()
				case <-quit:
				}
			}()

			for b.size == b.cap && !b.closed && ctx.Err() == nil {
				b.notFull.Wait()
			}
			close(quit)

			if ctx.Err() != nil {
				b.mu.Unlock()
				return ctx.Err()
			}
		}

		if b.closed {
			b.mu.Unlock()
			return b.closeErr
		}

		avail := b.cap - b.size
		chunk := len(data) - written
		if chunk > avail {
			chunk = avail
		}
		for i := 0; i < chunk; i++ {
			b.buf[(b.tail+i)%b.cap] = data[written+i]
		}
		b.tail = (b.tail + chunk) % b.cap
		b.size += chunk
		written += chunk
		b.notEmpty.Broadcast()
		b.mu.Unlock()
	}
	return nil
}

// Read reads up to len(p) bytes into p. Implements io.Reader.
// Blocks until data is available or the buffer is closed.
func (b *RecvBuffer) Read(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()

	for b.size == 0 {
		if b.closed {
			return 0, b.closeErr
		}
		b.notEmpty.Wait()
	}

	n := len(p)
	if n > b.size {
		n = b.size
	}
	for i := 0; i < n; i++ {
		p[i] = b.buf[(b.head+i)%b.cap]
	}
	b.head = (b.head + n) % b.cap
	b.size -= n
	b.notFull.Broadcast()
	return n, nil
}

// Close marks the buffer as closed. Subsequent Read calls drain remaining
// bytes then return closeErr (io.EOF for a clean stream end).
func (b *RecvBuffer) Close(closeErr error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.closed {
		return
	}
	b.closed = true
	if closeErr == nil {
		closeErr = io.EOF
	}
	b.closeErr = closeErr
	b.notEmpty.Broadcast()
	b.notFull.Broadcast()
}

// Reopen clears the closed flag so that Write can resume after a transient
// network disconnect. Data already in the buffer is preserved — the consumer
// continues reading seamlessly.
//
// This must only be called between connection cycles (after the old sender
// has stopped and before the new one starts). It is NOT safe to call
// concurrently with Write.
//
// Reopen is a no-op if the buffer is not closed.
func (b *RecvBuffer) Reopen() {
	b.mu.Lock()
	defer b.mu.Unlock()
	if !b.closed {
		return
	}
	b.closed = false
	b.closeErr = nil
	// Wake any blocked Write callers that were waiting on notFull.
	b.notFull.Broadcast()
}

// IsClosed reports whether the buffer has been closed.
func (b *RecvBuffer) IsClosed() bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.closed
}

// Available returns the number of bytes currently readable without blocking.
func (b *RecvBuffer) Available() int {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.size
}
